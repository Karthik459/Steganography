#include <stdio.h>
#include<string.h>
#include "encode.h"
#include "types.h"
int main(int argc,char *argv[])
{ 
  if((argc>=2&&argc<=5)&&check_operation_type(argv)==e_encode) // Checking if arguments are valid for encoding
  {
    printf("Selected Encoding\n");
    EncodeInfo encInfo; // Structure to hold encoding information

    if (read_and_validate_encode_args(argc,argv,&encInfo)==e_success) // Validate encoding arguments
    {
        printf("Success: Read and validate function\n");

        if (do_encoding(&encInfo)==e_success) // Perform encoding operation
        {
            printf("Encoding Finished\n");
        }
        else
        {
            printf("Encoding failure\n");
            return -1;
        }
    }
    else
    {
        printf("Failure: Read and validate function\n");
        return -1;
    }
   }
else
{
    printf("Please provide a valid operation: -e for Encoding or -d for Decryption\n");
    return -1;
}

}
OperationType check_operation_type(char **argv)
{
    if(strcmp(argv[1],"-e")==0)
        return e_encode;
    else if(strcmp(argv[1],"-d") == 0)
        return e_decode;
    else
        return e_unsupported;
}
Status do_encoding(EncodeInfo *encInfo)
{
    char str[10];
    printf("Enter the magic string:\n");
    scanf("%s",str);
    // Open files
    if (open_files(encInfo) != e_success)
    {
        printf("Failure: Open files function\n");
        return -1;
    }
    printf("Success: Open files function\n");
    // Check capacity
    if (check_capacity(encInfo) != e_success)
    {
        printf("Failure: Check capacity\n");
        return -1;
    }
    printf("Success: Check capacity\n");
    // Copy BMP header
    if (copy_bmp_header(encInfo->fptr_src_image,encInfo->fptr_stego_image)!=e_success)
    {
        printf("Failure: Copy .bmp header\n");
        return -1;
    }
    printf("Success: Copy .bmp header\n");
    // Encode magic string
    if (encode_magic_string(str,encInfo)!=e_success)
    {
        printf("Failure: Encode magic string\n");
        return -1;
    }
    printf("Success: Encode magic string\n");
    // Encode secret file extension size
    strcpy(encInfo->extn_secret_file, strstr(encInfo->secret_fname, "."));
    if (encode_secret_file_extn_size(strlen(encInfo->extn_secret_file), encInfo->fptr_src_image, encInfo->fptr_stego_image) != e_success)
    {
        printf("Failure: Encoding secret file extension size\n");
        return -1;
    }
    printf("Success: Encoded secret file extension size\n");
    // Encode secret file extension
    if (encode_secret_file_extn(encInfo->extn_secret_file, encInfo) != e_success)
    {
        printf("Failure: Encoding secret file extension\n");
        return -1;
    }
    printf("Success: Encoding secret file extension\n");
    // Encode secret file size
    if (encode_secret_file_size(encInfo->size_secret_file, encInfo) != e_success)
    {
        printf("Failure: Encoding secret file size\n");
        return -1;
    }
    printf("Success: Encoding secret file size\n");
    // Encode secret file data
    if (encode_secret_file_data(encInfo) != e_success)
    {
        printf("Failure: Encoding secret file data\n");
        return -1;
    }
    printf("Success: Encoding secret file data\n");
    // Copy remaining image data
    if (copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) != e_success)
    {
        printf("Failure: Copying remaining data\n");
        return -1;
    }
    printf("Success: Copied remaining data\n");
    printf("Encoding done successfully\n");
    return e_success;
}


